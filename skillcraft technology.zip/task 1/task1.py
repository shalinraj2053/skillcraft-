import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

data = pd.read_csv(r'C:\Users\LENOVO\Documents\skill craft 1\sales_data.csv')  

print("\nFirst 5 rows of the dataset:")
print(data.head())

print("\nShape of the dataset (rows, columns):")
print(data.shape)

print("\nSummary of dataset columns and data types:")
print(data.info())

print("\nStatistical summary of numerical columns:")
print(data.describe())

print("\nCount of missing values in each column:")
print(data.isnull().sum())

plt.figure(figsize=(6, 4))
sns.histplot(data['Customer_Age'], bins=20, color='skyblue')
plt.title('Distribution of Customer Ages')
plt.xlabel('Age')
plt.ylabel('Count')
plt.show()

plt.figure(figsize=(6, 4))
sns.countplot(x='Customer_Gender', data=data, hue='Customer_Gender', palette='Set2', legend=False)
plt.title('Distribution of Customer Genders')
plt.xlabel('Gender')
plt.ylabel('Count')
plt.show()

