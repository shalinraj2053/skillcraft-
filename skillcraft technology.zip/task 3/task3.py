import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.tree import DecisionTreeClassifier, plot_tree
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, confusion_matrix
import warnings

warnings.filterwarnings('ignore')
sns.set_style('darkgrid')

df = pd.read_csv(r'C:\Users\LENOVO\Documents\skill craft 3\PreprocessedBank.csv')

df.drop(columns=['Unnamed: 0'], inplace=True)

print(df.head())
print(df.info())
print(df.describe())

plt.figure(figsize=(6,4))
sns.histplot(df['age'], bins=30, color='skyblue')
plt.title('Age Distribution')
plt.show()

plt.figure(figsize=(6,4))
sns.histplot(df['balance'], bins=30, color='orange')
plt.title('Balance Distribution')
plt.show()

plt.figure(figsize=(6,4))
sns.histplot(df['duration'], bins=30, color='green')
plt.title('Call Duration Distribution')
plt.show()

sns.countplot(x='deposit', data=df, palette='Set2')
plt.title('Purchase Distribution (Target Variable)')
plt.show()

plt.figure(figsize=(12,8))
sns.heatmap(df.corr(), cmap='coolwarm', annot=False)
plt.title('Correlation Heatmap')
plt.show()


# Decision Tree Classifier


X = df.drop(columns=['deposit'])
y = df['deposit']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

model = DecisionTreeClassifier(max_depth=4, random_state=42)
model.fit(X_train, y_train)

y_pred = model.predict(X_test)

acc = accuracy_score(y_test, y_pred)
cm = confusion_matrix(y_test, y_pred)

print(f"\nDecision Tree Accuracy: {acc*100:.2f}%")
print("Confusion Matrix:")
print(cm)

plt.figure(figsize=(20,10))
plot_tree(model, feature_names=X.columns, class_names=['No', 'Yes'], filled=True)
plt.show()
