import numpy as np
import pandas as pd
import seaborn as sns
import warnings
import matplotlib.pyplot as plt
import folium
from folium.plugins import HeatMap

warnings.filterwarnings('ignore')
sns.set_style('darkgrid')

# Load dataset (update path if needed)
df = pd.read_csv(r'C:\Users\adars\Downloads\US_Accidents_March23.csv')

# Basic info
print(df.head())
print(df.columns)
print(df.info())
print(df.describe())

# Missing values visualization
missing_values = df.isna().sum()
missing_ratio = missing_values / len(df)
missing_ratio.plot(kind='barh', figsize=(8, 6), color='orange')
plt.title('Missing Values Ratio')
plt.show()

# Top 20 cities with most accidents
accident_per_city = df['City'].value_counts()
print(accident_per_city.head(20))

# Bar plot for top 20 cities
accident_per_city.head(20).sort_values(ascending=True).plot(kind='barh', color='skyblue')
plt.title('Top 20 Cities with Most Accidents')
plt.xlabel('Number of Accidents')
plt.show()

# Distribution of accidents per city
sns.histplot(accident_per_city, bins=50, color='green')
plt.title('Accidents per City Distribution')
plt.xlabel('Number of Accidents')
plt.show()

# High and low accident cities
high_accident_cities = accident_per_city[accident_per_city >= 1000]
low_accident_cities = accident_per_city[accident_per_city < 1000]

total_cities = df['City'].nunique()
high_percentage = len(high_accident_cities) / total_cities * 100
low_percentage = len(low_accident_cities) / total_cities * 100

print(f"High accident cities: {high_percentage:.2f}%")
print(f"Low accident cities: {low_percentage:.2f}%")

sns.histplot(high_accident_cities, bins=30, color='red')
plt.title('High Accident Cities Distribution')
plt.show()

# Convert Start_Time to datetime
df['Start_Time'] = pd.to_datetime(df['Start_Time'], errors='coerce')

# Hourly distribution
sns.histplot(df['Start_Time'].dt.hour, bins=24, color='red')
plt.title('Hourly Distribution of Accidents')
plt.xlabel('Hour of Day')
plt.show()

# Day of week distribution
sns.histplot(df['Start_Time'].dt.dayofweek, bins=7, color='red')
plt.title('Day of Week Distribution of Accidents')
plt.xlabel('Day of Week (0=Mon, 6=Sun)')
plt.show()

# Sunday and Saturday hourly distribution
sun_day = df['Start_Time'][df['Start_Time'].dt.dayofweek == 6]
sat_day = df['Start_Time'][df['Start_Time'].dt.dayofweek == 5]

fig, axis = plt.subplots(2, 1, figsize=(12, 5))
sns.histplot(sun_day.dt.hour, bins=24, color='red', ax=axis[0])
axis[0].set_title('Sunday Hourly Accident Distribution')

sns.histplot(sat_day.dt.hour, bins=24, color='red', ax=axis[1])
axis[1].set_title('Saturday Hourly Accident Distribution')

fig.tight_layout()
plt.show()

# Monthly distribution
sns.histplot(df['Start_Time'].dt.month, bins=12, color='black')
plt.title('Monthly Distribution of Accidents')
plt.xlabel('Month')
plt.show()

# Year-wise monthly distribution
for year in [2016, 2017, 2018, 2019,2020,2021,2022,2023]:
    data_year = df['Start_Time'][df['Start_Time'].dt.year == year]
    sns.histplot(data_year.dt.month, bins=12, color='yellow')
    plt.title(f'Monthly Distribution of Accidents - {year}')
    plt.xlabel('Month')
    plt.show()

# Data by Source in 2023
data_2023 = df[df['Start_Time'].dt.year == 2023]
df_2023_data_src1 = data_2023[data_2023['Source'] == 'Source1']['Start_Time']
df_2023_data_src2 = data_2023[data_2023['Source'] == 'Source2']['Start_Time']

plt.figure(figsize=(12, 4))

plt.subplot(1, 2, 1)
sns.histplot(df_2019_data_src1.dt.month, bins=12, color='green')
plt.title('2019 Data Collected from Source1')

plt.subplot(1, 2, 2)
sns.histplot(df_2019_data_src2.dt.month, bins=12, color='green')
plt.title('2019 Data Collected from Source2')

plt.tight_layout()
plt.show()

# Source distribution
df['Source'].value_counts().plot(kind='pie', autopct='%1.1f%%', figsize=(6, 6))
plt.title('Accident Source Distribution')
plt.ylabel('')
plt.show()

# Scatter plot of accident locations
plt.figure(figsize=(8, 6))
sns.scatterplot(x=df['Start_Lng'], y=df['Start_Lat'], alpha=0.1, s=1, color='purple')
plt.title('Accident Locations Scatter Plot')
plt.show()

# Heatmap for first 50 locations
lat_lng_pairs = list(zip(df['Start_Lat'][:50], df['Start_Lng'][:50]))
map_ = folium.Map(location=[df['Start_Lat'][:50].mean(), df['Start_Lng'][:50].mean()], zoom_start=10)
HeatMap(lat_lng_pairs).add_to(map_)

# Save heatmap to HTML
map_.save('heatmap.html')
print("Heatmap saved as 'heatmap.html'. Open it in your browser to view.")

# Temperature distribution in Celsius
df['Temp_Celsius'] = (df['Temperature(F)'] - 32) * 5/9
sns.histplot(df['Temp_Celsius'], bins=50, color='purple')
plt.title('Temperature Distribution (°C)')
plt.xlabel('Temperature (°C)')
plt.show()

# Colder and warmer distributions based on Celsius
colder = df[df['Temp_Celsius'] <= 15]['Temp_Celsius']
warmer = df[df['Temp_Celsius'] > 15]['Temp_Celsius']

sns.histplot(colder, bins=30, color='blue')
plt.title('Colder Temperature Distribution (≤15°C)')
plt.show()

# Top 20 weather conditions
df['Weather_Condition'].value_counts().head(20).plot(kind='barh', color='orange')
plt.title('Top 20 Weather Conditions')
plt.show()

# Unique weather conditions
total_weather_conditions = df['Weather_Condition'].nunique()
print(f"Total unique weather conditions: {total_weather_conditions}")

# Accidents per weather condition
accidents_per_weather = df['Weather_Condition'].value_counts()
sns.histplot(accidents_per_weather, bins=50, color='violet')
plt.title('Accidents per Weather Condition Distribution')
plt.show()
